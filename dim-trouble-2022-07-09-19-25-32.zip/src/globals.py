import pygame


pygame.init()


__all__ = [
    "DISP_ICO",
    "DISP_WID",
    "DISP_HEI",
    "DISP_TIT",
    "display",
    "font",
    "FPS",
    "clock",
    "config",
    "UP",
    "DOWN",
    "RIGHT",
    "LEFT",
    "PAUSE",
    "ACCEPT",
]


########### Window Properties ###########

DISP_WID = 400
DISP_HEI = 240
DISP_TIT = "Dimensional Trouble Temporary Title"
DISP_ICO = "icon/path/still/to/determine"

font = pygame.font.Font("data/fonts/dogica.ttf", 40)

pygame.display.set_caption(DISP_TIT)

display = pygame.display.set_mode(
    (DISP_WID, DISP_HEI), pygame.RESIZABLE | pygame.SCALED
)

FPS = 60
clock = pygame.time.Clock()
game_mode = None

#################### Configurations ######################

config = {
    "key": {
        "up": pygame.K_UP,
        "down": pygame.K_DOWN,
        "left": pygame.K_LEFT,
        "right": pygame.K_RIGHT,
        "pause": pygame.K_ESCAPE,
        "accept": pygame.K_RETURN,
    }
}

RIGHT = config["key"]["right"]
LEFT = config["key"]["left"]
UP = config["key"]["up"]
DOWN = config["key"]["down"]
PAUSE = config["key"]["pause"]
ACCEPT = config["key"]["accept"]

######################## Game Data ########################

game_data = dict(map=None, posX=64, posY=64, cam_x=0, cam_y=0, dialogResponses={})
