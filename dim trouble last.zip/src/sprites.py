import pygame


sprite_tux = pygame.image.load("res/gfx/Tux/taletuxNL.png").convert_alpha()
sprite_block = pygame.image.load("res/gfx/tiles/block.png").convert_alpha()
sprite_marbel = pygame.image.load(
    "res/gfx/tiles/blue_marbel 2.5d_v1.0.png"
).convert_alpha()
sprite_slime = pygame.image.load("res/gfx/tiles/slimes sheet.png").convert_alpha()
sprite_soul = pygame.image.load("res/gfx/Soul/soul.png").convert_alpha()
sprite_bullet = pygame.image.load("res/gfx/Soul/bullet.png").convert_alpha()
sprite_tree = pygame.image.load("res/gfx/tiles/big tree.png").convert_alpha()
